<?php
/*=====================================
    Disallow file edit in dashboard
=======================================*/
define('DISALLOW_FILE_EDIT', true);

/*=====================================
    Hide WP Version Number
=======================================*/

function hideWPVersion(){
    remove_filter('update_footer', 'core_update_footer');
}

add_action('admin_menu', 'hideWPVersion');

/*=====================================
   
    add stylesheets and js files
======================================*/
function custom_theme_scripts(){
    //bootstrap css
    wp_enqueue_style('bootstrap', get_stylesheet_directory_uri() . '/css/bootstrap.min.css');
    //wp_enqueue_style('bootstrap-grid', get_stylesheet_directory_uri() . 'css/bootstrap-grid.min.css');

    //main css
    wp_enqueue_style('main-styles', get_stylesheet_uri());

    //added this line duing the color box video
    wp_enqueue_script('jquery');

    //colorbox
    wp_enqueue_style('colorbox-css', get_stylesheet_directory_uri() . '/assets/colorbox/colorbox.css');
    wp_enqueue_script('colorbox-js', get_stylesheet_directory_uri() . '/assets/colorbox/jquery.colorbox.js');
    wp_enqueue_script('colorbox-js-custom', get_stylesheet_directory_uri() . '/assets/colorbox/custom.js');


    //js files
    wp_enqueue_script('bootstrap-js', get_stylesheet_directory_uri() . '/js/bootstrap.min.js' );
    wp_enqueue_script('custom-js', get_stylesheet_directory_uri() . '/js/scripts.js');
}

add_action('wp_enqueue_scripts', 'custom_theme_scripts');


/*==============================
    
    adds featured images

===============================*/
add_theme_support('post-thumbnails');

/*==============================
    
    custom header image

===============================*/
$custom_image_header = array(
    'width'     => 125,
    'height'    => 125,
    'uploads'   => true,
);

add_theme_support('custom-header', $custom_image_header);



















/*======================================================
   
    post data info

=======================================================*/
function post_data(){
    $archive_year   = get_the_time('Y');
    $archive_month  = get_the_time('m');
    $archive_day    = get_the_time('d');
?>

<p>Edited by: <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>"><?php echo get_the_author(); ?></a> | Published on: <a href="<?php echo get_day_link($archive_year, $archive_month, $archive_day); ?>"><?php echo "$archive_month/$archive_day/$archive_year"; ?></a></p>

<?php }


/*======================================================
   
    archive sidebar

=======================================================*/

function archiveSidebar(){?>
    <aside class="col-lg-3 archive-sidebar">
        <h2>Archives by Category:</h2>
        <ul class="category-list">
            <?php
                wp_list_categories(array(
                    "orderby"       => "name",
                    "show_count"    => true,
                    "title_li"      => "",
                ));
            ?>
        </ul>
        <h2>Archives by Tag:</h2>          
        <ul class="tag-list">
            <?php
                $tags   =   get_tags();
                foreach($tags as $tag ){
                    echo '<li><a href="' . get_tag_link($tag->term_id) . '" rel="tag">' . $tag->name . ' (' . $tag->count . ')</a></li>';
                }
            ?>
        </ul>
        <h2>Last 10 Posts:</h2>
        
        <ul class="recent-posts">
            <?php
                $archive_10 = get_posts('numberposts=10');
                foreach($archive_10 as $post){ ?>
                    <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
        <?php }
            ?>
        </ul>
        <h2>Archives by Month:</h2>
        <ul class="monthly-list">
            <?php
                wp_get_archives(array(
                    'type'              => 'monthly',
                    'show_post_count'   => 'true',
                )); ?>
        </ul>
    </aside>
<?php }

/*=====================================================
   
    add menus to our theme

=======================================================*/

function register_my_menus(){
    register_nav_menus(array(
        'main-menu'     => __('Main Menu'),
        'footer-left'   => __('Left Footer Menu'),
        'footer-middle' => __('Middle Footer Menu'),
        'footer-right'  => __('Right Footer Menu')
    ));
}

add_action('init', 'register_my_menus');









/*============================================================================================================
    
    add pagination links to our theme https://developer.wordpress.org/reference/functions/paginate_links/

==============================================================================================================*/

function testPagination(){
    global $wp_query;

    $big = 999999999; // need an unlikely integer
    $translated = __( 'Page', 'mytextdomain' ); // Supply translatable string
 
    echo paginate_links( array(
        'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
        'format' => '?paged=%#%',
        'current' => max( 1, get_query_var('paged') ),
        'total' => $wp_query->max_num_pages,
            'before_page_number' => '<span class="screen-reader-text">'.$translated.' </span>'
    ) );
}

/*============================================================================================================
   
    post navigation

==============================================================================================================*/

function testPostNavigation(){?>
    <div class="post-navigation-container col-sm-8">
        <div class="previous-post-link col-sm-6">
            <?php previous_post_link(); ?>
        </div>

        <div class="next-post-link col-sm-6">
            <?php next_post_link(); ?>
        </div>
    </div>


<?php }





/*=================================================================

    Create Widget Areas

==================================================================*/

function blank_widgets_init(){
    register_sidebar(array(
        'name'          => ('Top Right Header'),
        'id'            => 'top-right-header',
        'description'   => 'Area in top right of header',
        'before_widget' => '<div class="top-right-header-container">',
        'after_widget'  =>  '</div>',
        'before_title'  =>  '<h3>',
        'after_title'   =>  '</h3>'
    ));

    register_sidebar(array(
        'name'          => ('Sidebar'),
        'id'            => 'sidebar',
        'description'   => 'Widget area in sidebar',
        'before_widget' => '<div class="sidebar">',
        'after_widget'  =>  '</div>',
        'before_title'  =>  '<h3>',
        'after_title'   =>  '</h3>'
    ));

    register_sidebar(array(
        'name'          => ('Left Footer'),
        'id'            => 'left-footer',
        'description'   => 'Widget area in left of footer',
        'before_widget' => '<div class="left-footer">',
        'after_widget'  =>  '</div>',
        'before_title'  =>  '<h3>',
        'after_title'   =>  '</h3>'
    ));

    register_sidebar(array(
        'name'          => ('Center Left Footer'),
        'id'            => 'center-left-footer',
        'description'   => 'Widget area center left of footer',
        'before_widget' => '<div class="center-left-footer">',
        'after_widget'  =>  '</div>',
        'before_title'  =>  '<h3>',
        'after_title'   =>  '</h3>'
    ));

    register_sidebar(array(
        'name'          => ('Archive Sidebar'),
        'id'            => 'archive-sidebar',
        'description'   => 'Widget area in archive sidebar',
        'before_widget' => '<div class="archive-sidebar">',
        'after_widget'  =>  '</div>',
        'before_title'  =>  '<h3>',
        'after_title'   =>  '</h3>'
    ));


}

add_action('widgets_init', 'blank_widgets_init');


/*==============================================================


    Company Staff Directory Shortcode


================================================================*/
function companyStaffDirectoryShortcode($atts){
    extract( shortcode_atts(array(
        'category'      =>  '',
        'image'         =>  '',
        'excerpt'       =>  'yes',
        'totalposts'    =>  '4',
        'orderby'       =>  'name', //date
        'order'         =>  'DESC',
        'design'        =>  'blocks',
    ), $atts));

    //custom query
    $args = array(
        'post_type'     =>  'company-team-members',
        'post_status'   =>  'published',
        'posts_per_page'=>  "$totalposts",
        'order'         =>  "$order",
        'orderby'       =>  "$orderby",
        'tax_query'     =>  array(
            array (
                'taxonomy'  =>  "team-member-position",
                'field'     =>  "slug",
                'terms'     =>  "$category"
            )
        )
    );

    $query = new WP_Query($args);

    if($design == "blocks"){
    
    $output = "<div class='row'>";

    if($query->have_posts()){
        while($query->have_posts()){
            $query->the_post();

            //open individual post container
            $output .="<div class='col-lg-3'>";

            //featured image
            if($image == "yes"){
                $output .= get_the_post_thumbnail($query->ID, 'thumbnail');
            }

            //post title
            $output .= "<div class='post-title'>";
            $output .= '<a href="' . get_the_permalink() . '">' . get_the_title() . '</a>';
            $output .= "</div>";

            //excerpt 
            if($excerpt == "yes"){
                $output .= get_the_excerpt();
            }

            $output .= "</div>";
        }//end while loop
    }//end if statement
    
    $output .= "</div>";

    return $output;
}elseif($design == "list"){
    $output = "<div class='row'>";
    if($query->have_posts()){
        //open individual post container
        $output .= "<ul class='col-lg-12'>";
        
        while($query->have_posts()){
            $query->the_post();

            
            

            //post title
            $output .= "<li class='post-title'>";
            $output .= '<a href="' . get_the_permalink() . '">' . get_the_title() . '</a>';
            $output .= "</li>";

        }//end while loop
        $output .= "</ul>";
        
    }//end if statement

    $output .= "</div>";

    return $output;
    
    }   
}//ends function

add_shortcode('ejAgonKresky-company-staff-directory', 'companyStaffDirectoryShortcode');



/*==============================================================


    Breadcrumbs


================================================================*/



function personalTrainingBreadcrumb() {
  $delimiter = '<i class="fas fa-angle-double-right"></i>';
  $name = 'Home'; //text for the 'Home' link
  $currentBefore = '<span class="current">';
  $currentAfter = '</span>';

  if ( !is_home() && !is_front_page() || is_paged() ) {

    echo '<div class="wrap" id="crumbs">';

    global $post;
    $home = get_bloginfo('url');
    echo '<a href="' . $home . '">' . $name . '</a> ' . $delimiter . ' ';

    if ( is_category() ) {
      global $wp_query;
      $cat_obj = $wp_query->get_queried_object();
      $thisCat = $cat_obj->term_id;
      $thisCat = get_category($thisCat);
      $parentCat = get_category($thisCat->parent);
      if ($thisCat->parent != 0) echo(get_category_parents($parentCat, TRUE, ' ' . $delimiter . ' '));
      echo $currentBefore . 'Archive by category &#39;';
      single_cat_title();
      echo '&#39;' . $currentAfter;

    } elseif ( is_day() ) {
      echo '<a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . $delimiter . ' ';
      echo '<a href="' . get_month_link(get_the_time('Y'),get_the_time('m')) . '">' . get_the_time('F') . '</a> ' . $delimiter . ' ';
      echo $currentBefore . get_the_time('d') . $currentAfter;

    } elseif ( is_month() ) {
      echo '<a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . $delimiter . ' ';
      echo $currentBefore . get_the_time('F') . $currentAfter;

    } elseif ( is_year() ) {
      echo $currentBefore . get_the_time('Y') . $currentAfter;

    } elseif ( is_single() && !is_attachment() ) {
      $cat = get_the_category(); $cat = $cat[0];
      echo get_category_parents($cat, TRUE, ' ' . $delimiter . ' ');
      echo $currentBefore;
      the_title();
      echo $currentAfter;

    } elseif ( is_attachment() ) {
      $parent = get_post($post->post_parent);
      $cat = get_the_category($parent->ID); $cat = $cat[0];
      echo get_category_parents($cat, TRUE, ' ' . $delimiter . ' ');
      echo '<a href="' . get_permalink($parent) . '">' . $parent->post_title . '</a> ' . $delimiter . ' ';
      echo $currentBefore;
      the_title();
      echo $currentAfter;

    } elseif ( is_page() && !$post->post_parent ) {
      echo $currentBefore;
      the_title();
      echo $currentAfter;

    } elseif ( is_page() && $post->post_parent ) {
      $parent_id  = $post->post_parent;
      $breadcrumbs = array();
      while ($parent_id) {
        $page = get_page($parent_id);
        $breadcrumbs[] = '<a href="' . get_permalink($page->ID) . '">' . get_the_title($page->ID) . '</a>';
        $parent_id  = $page->post_parent;
      }
      $breadcrumbs = array_reverse($breadcrumbs);
      foreach ($breadcrumbs as $crumb) echo $crumb . ' ' . $delimiter . ' ';
      echo $currentBefore;
      the_title();
      echo $currentAfter;

    } elseif ( is_search() ) {
      echo $currentBefore . 'Search results for &#39;' . get_search_query() . '&#39;' . $currentAfter;

    } elseif ( is_tag() ) {
      echo $currentBefore . 'Posts tagged &#39;';
      single_tag_title();
      echo '&#39;' . $currentAfter;

    } elseif ( is_author() ) {
       global $author;
      $userdata = get_userdata($author);
      echo $currentBefore . 'Articles posted by ' . $userdata->display_name . $currentAfter;

    } elseif ( is_404() ) {
      echo $currentBefore . 'Error 404' . $currentAfter;
    }

    if ( get_query_var('paged') ) {
      if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ' (';
      echo __('Page') . ' ' . get_query_var('paged');
      if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ')';
    }

    echo '</div>';

  }
}

/**=========================================

  Theme Settings

=============================================*/

function project2_theme_settings_page(){ ?>
  <div class="wrap">
    <h1>Project2 Theme</h1>
    <p>Here you can set up your Facebook, Instagram, and Google Analytics accounts!</p>
    <p>More settings coming soon</p>
    <form method="post" action="options.php">
      <?php
       settings_fields('project2-section'); //Register Section
       do_settings_sections('project2-options'); //Group ID for all of the fields
       submit_button();
      ?>
    </form>
<?php }
function display_instagram_element(){ ?>
  <input type="text" name="instagram_url" id="instagram_url" value="<?php echo get_option('instagram_url'); ?>" /><?php
}

function display_facebook_element(){ ?>
  <input type="text" name="facebook_url" id="facebook_url" value="<?php echo get_option('facebook_url'); ?>" /><?php
}

function display_google_analytics_element(){ ?>
  <input type="text" name="google_analytics_code" id="google_analytics_code" value="<?php echo get_option('google_analytics_code'); ?>" /><?php
}

function display_theme_panel_fields(){
  add_settings_section('project2-section', "All settings", null, 'project2-options');
  
  add_settings_field('instagram_url', 'Instagram Profile URL', 'display_instagram_element', 'project2-options', 'project2-section');
  add_settings_field('facebook_url', 'Facebook Profile URL', 'display_facebook_element', 'project2-options', 'project2-section');
  add_settings_field('google_analytics_code', 'Google Analytics Tracking ID (example UA-1234567-1)', 'display_google_analytics_element', 'project2-options', 'project2-section');
  
  register_setting('project2-section', 'instagram_url');
  register_setting('project2-section', 'facebook_url');
  register_setting('project2-section', 'google_analytics_code');
}

add_action('admin_init', 'display_theme_panel_fields');
function add_theme_menu_item(){
  add_menu_page('Project2 Theme', 'Project2 Theme', 'manage_options', 'theme-panel', 'project2_theme_settings_page', 'dashicons-universal-access-alt', 1);
}

add_action('admin_menu', 'add_theme_menu_item');

/*===============================================

    Google Analytics

================================================*/
function themeGoogleAnalytics(){
    $googleAnalytics = get_option('google_analytics_code');
    ?>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo $googleAnalytics; ?>"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', '<?php echo $googleAnalytics; ?>');
    </script>
<?php }

add_action('wp_head', 'themeGoogleAnalytics'); 