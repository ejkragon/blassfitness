<?php get_header(); ?>
<div class="container">

    <div class="crumbs-no-hero">    
        <?php
        //adds breadcrumbs
            personalTrainingBreadcrumb();
        ?>
    </div>

    <main class="row">
        <?php
            if(have_posts()){
                while(have_posts()){
                    the_post();?>
                    <section class="col-md-9">
                        
                        <?php the_post_thumbnail('medium'); ?>
                        <h4><?php the_title(); ?></h4>

                        <p><?php echo 'Post edited by: ' . get_the_author() . ' | Published on: ' . get_the_date(); ?></p>
                                                
                        <p><?php echo the_content(); ?></p>
                    </section>
                <?php } // end while
            } // end if

            if (comments_open() || get_comments_number()):
                comments_template();
            endif;
?>

    </main> <!-- row -->

    <?php 
        testPostNavigation();
    ?>








</div>  <!-- container -->
    
<?php get_footer(); ?>