<?php get_header(); ?>
<div class="container">

    <div class="crumbs-no-hero">    
        <?php
        //adds breadcrumbs
            personalTrainingBreadcrumb();
        ?>
    </div>
    
    <main class="row">
        
        <?php get_search_form(); ?>
        
        <?php
        if(have_posts()){
            while(have_posts()){
                the_post(); ?>
                <article class="col-md-12">
                    <?php the_post_thumbnail('thumbnail'); ?>

                    <h2><?php echo get_the_title(); ?></h2>

                    <p><?php echo get_the_excerpt(); ?></p>

                    <a class="btn btn-primary btn-sm" href="<?php the_permalink(); ?>">Read more about this article</a>
                </article>
            <?php
        }// end while

        //pagination
        testPagination();

    }// end if
    
    ?>
    </main> <!-- row -->
</div> <!-- container -->


<?php get_footer(); ?>