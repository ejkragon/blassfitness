<?php 
    /*
        Template Name: Hero Image Template
        Template Post Type: page
    */

get_header();

    if(have_posts()){
        while (have_posts()) {
            the_post(); ?>
            <div class="hero-container">
                <div class="hero-image">
                    <?php the_post_thumbnail('full'); ?>
                </div>

                <div class="hero-title container">
                    <?php the_title(); ?>
                </div>
            </div>

            <main class="container">
                <div class="row">
                                     
                    <section class="col-md-9">
                        <?php
                        //adds breadcrumbs
                            personalTrainingBreadcrumb();
                        ?>

                        <?php the_content(); ?>
                    </section>

                    <aside class="sidebar-container col-md-3">
                        <?php get_sidebar(); ?>
                    </aside>
                </div>
            </main>



        <?php   }//end while
            }//end of if
        ?>                    

<?php get_footer(); ?>
