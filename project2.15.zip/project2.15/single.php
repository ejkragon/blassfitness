<?php get_header(); ?>
<div class="container">

    <?php
    //adds breadcrumbs
        personalTrainingBreadcrumb();
    ?>

    <main class="row">
        <?php
            if(have_posts()){
                while(have_posts()){
                    the_post();?>
                    <section class="col-md-12">
                        <h2><?php the_title(); ?></h2>
                        <?php the_post_thumbnail('large'); ?>

                        <p><?php echo 'Post written by: ' . get_the_author() . ' | Published on: ' . get_the_date(); ?></p>
                                                
                        <p><?php echo the_content(); ?></p>
                    </section>
                <?php } // end while
            } // end if

            if (comments_open() || get_comments_number()):
                comments_template();
            endif;
?>

    </main> <!-- row -->

    <?php 
        testPostNavigation();
    ?>

</div>  <!-- container -->
    
<?php get_footer(); ?>