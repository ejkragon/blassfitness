<?php 
    /*
        Template Name: Left Sidebar
        Template Post Type: page
    */

get_header();

    if(have_posts()){
        while (have_posts()) {
            the_post(); ?>
            <div class="hero-container">
                <div class="hero-image">
                    <?php the_post_thumbnail('full'); ?>
                </div>

                <div class="hero-title container">
                    <?php the_title(); ?>
                </div>
            </div>

            <main class="container">

                    <?php
                    //adds breadcrumbs
                        personalTrainingBreadcrumb();

                    ?>

                <div class="row">
                
                    <aside class="sidebar-container col-md-3">
                        <?php get_sidebar(); ?>
                    </aside>

                    <section class="col-md-9">
                        <?php the_content(); ?>
                    </section>
                                       
                </div>
            </main>



        <?php   }//end while
            }//end of if
        ?>                    

<?php get_footer(); ?>
