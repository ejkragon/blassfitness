<?php get_header(); ?>
<!--breadcrumb video, this seems to be a new line-->
<?php the_post_thumbnail(); ?>

<div class="container">

    <?php
    //adds breadcrumbs
        personalTrainingBreadcrumb();

    ?>
    
    <main class="row">
        <?php
            if(have_posts()){
                while(have_posts()){
                    the_post();?>
                    <section class="col-md-12">
                        <h2><?php the_title(); ?></h2>
                                                                      
                        <p><?php echo the_content(); ?></p>
                        
                    </section>
                <?php } // end while

                //pagination
                testPagination();
                
            } // end if
        
        //custon query
        $args = array(
            'post_type'         =>  'post',
            'post_status'       =>  'published',
            'posts_per_page'    =>  '3',
            'order'             =>  'DESC',
            'orderby'           =>  'modified',
            'category_name'     =>  'promotions'
        );

        $query = new WP_Query($args);

        if($query->have_posts()){
            while($query->have_posts()){
                $query->the_post(); ?>
                    <div class="col-md-4">
                    <?php echo get_the_post_thumbnail($query->ID, 'thumbnail'); ?>

                    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <p><?php the_excerpt(); ?></p>
                </div>
                <?php

            }
        }

        ?>
    </main> <!-- row -->
</div>  <!-- container -->
    
<?php get_footer(); ?>