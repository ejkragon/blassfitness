**Things I need to work on/need help with:**

1. ~~RESOLVED 11/10 - For company directory, 2 and not 3 posts are showing on the bottom. Issue with loop on archive? Warning but no error in the query monitor. ~~
2. ~~RESOLVED 11/10 -  Categories also only showing two posts before forcing user to go to another page. ~~
3. For header, bootstrap was not displaying menu items as block. Removed it for now, but hope to use for final project. Bootstrap Navwalker
   1. Drop down menu
   2. What should replace "#"? (index.php and page-home.php did not work) 
4. ~~ Logo in nav bar 11/19 - I think there was an offer to show us how to move logo or title of the site so that is is above the hero image. I don't care for the default logo location. ~~
5. Setmore widget button appears as expected in post itself, but not when it is pulled into custom query
6. ~~ Resolved 11/19 Need to style the post titles when they are being pulled into custom query, where is this being controlled? ~~
7. ~~ADDED BG GRAY 11/19 - Need to put a border around the sidebar~~
8. ~~RESOLVED 11/10 - Double check roboto font~~
9.  Why is image of woman on ball fine on the post but pixalated in custom query?
10. Breadcrumb not appearing correctly on homepage. Widget? About and Home using same template
11. ~~RESOLVED 11/10 - FontAwesome left and right arrows~~
12. Add $i lines to index file (consider only using thumbnail at the top); where can i find repo (11/10)
13. ~~ Keeping posts for the 3 options Use html/bootstrap to offer the three options for personal training (11/10) ~~
14. ~~ Keeping posts for the 3 options Add custom fields (11/10) - rewatch the video to see if custom field is preferable over #13 bs ~~
15. ~~ Check for errors in browser - I don't think VS Code is showing me errors and warnings correctly (see screen shot taken 11/17) ~~
16. Efren helped make the navbar readable, but the hamburger does not do anything (11/18)
17. Theme settings - my Instagram URL input field is outside of the box (11/24)
18. Google Analytics - blassfitness.com or kragonconsulting.com/blassfitness (11/24)
19. Remove unused plugins
20. ~~ Disabled security lines of code 11/30 All the images in WordPress have disappeared (11/29) ~~
21. Widgets appear on live site, but not on localhost (11/30)
22. Correct way to comment out PHP? (12/1)
23. Why can't I replace archive sidebar with content aware? (12/1)
24. Company staff directory as part of about me? (12/1)
