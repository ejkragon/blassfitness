        <footer>
            <div class="container">
                <nav class="row">
                    <div class="col-md-4">
                        <?php 
                            dynamic_sidebar('left-footer'); 
                        ?>
                    
                        <div class="social-media">
                            <h3></h3>
                            <div class="facebook-container">
                                <?php
                                    $facebook = get_option('facebook_url');

                                    if(!empty($facebook)){ ?>
                                        <a href="<?php echo $facebook; ?>" target="_blank"><i class="fa-brands fa-facebook" aria-hidden="true"></i></a>
                                        <?php 
                                    } 
                                ?>
                            </div>

                            <div class="instagram-container">
                                <?php
                                    $facebook = get_option('instagram_url');
                                    if(!empty($instagram)){ ?>
                                        <a href="<?php echo $instagram; ?>" target="_blank"><i class="fa-brands fa-instagram-square" aria-hidden="true"></i></a>
                                        <?php 
                                    } 
                                ?>
                            </div>

                        </div>
                    
                    
                    </div>

                    <div class="col-md-4">
                        <h5>Services</h5>
                        <?php
                            if(has_nav_menu('footer-middle')){
                                wp_nav_menu(array(
                                    'theme_location' => 'footer-middle',
                                    'container_class' => 'footer-middle'
                                   
                                ));
                            }else{
                                echo "<p>Please select a main menu through the dashboard</p>";
                            }
                        ?>
                    </div>

                    <div class="col-md-4">
                        <h5>Quick Links</h5>
                        <?php
                            if(has_nav_menu('footer-right')){
                                wp_nav_menu(array(
                                    'theme_location' => 'footer-right',
                                    'container_class' => 'footer-right'
                                ));
                            }else{
                                echo "<p>Please select a main menu through the dashboard</p>";
                            }
                        ?>
                    </div>


                </div>
            </nav>
        </footer>
        <?php wp_footer(); ?>
    </body>
</html>